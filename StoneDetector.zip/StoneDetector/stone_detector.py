
import os
import subprocess
from qgis.PyQt.QtCore import QSettings, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox, QInputDialog
from qgis.core import QgsMessageLog, Qgis

PLUGIN_NAME = "StoneDetector"
SETTINGS_GROUP = "StoneDetector"

class StoneDetectorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def tr(self, text):
        return QCoreApplication.translate(PLUGIN_NAME, text)

    def initGui(self):
        self.action = QAction(self.tr("StoneDetector — detect stones"), self.iface.mainWindow())
        self.action.triggered.connect(self.run_dialog)
        self.iface.addPluginToMenu(self.tr("&StoneDetector"), self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.tr("&StoneDetector"), self.action)
            self.iface.removeToolBarIcon(self.action)

    def _get_engine_path(self):
        s = QSettings()
        s.beginGroup(SETTINGS_GROUP)
        engine = s.value("engine_path", "", type=str)
        s.endGroup()
        return engine

    def _set_engine_path(self, path):
        s = QSettings()
        s.beginGroup(SETTINGS_GROUP)
        s.setValue("engine_path", path)
        s.endGroup()

    def run_dialog(self):
        tif_path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            self.tr("Select input TIFF"),
            "",
            "GeoTIFF (*.tif *.tiff)"
        )
        if not tif_path:
            return

        out_dir = QFileDialog.getExistingDirectory(
            self.iface.mainWindow(),
            self.tr("Select output folder")
        )
        if not out_dir:
            return

        engine_path = self._get_engine_path()
        if not engine_path or not os.path.exists(engine_path):
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                self.tr("First run: please select stone_detector.exe")
            )
            engine_path, _ = QFileDialog.getOpenFileName(
                self.iface.mainWindow(),
                self.tr("Select stone_detector.exe"),
                "",
                "Executable (*.exe)"
            )
            if not engine_path:
                return
            self._set_engine_path(engine_path)

        thr, ok = QInputDialog.getDouble(
            self.iface.mainWindow(),
            self.tr("Threshold"),
            self.tr("Mask threshold (default 0.01). Lower -> more stones, higher -> fewer."),
            value=0.01, min=0.0, max=1.0, decimals=4
        )
        if not ok:
            thr = None

        cmd = [engine_path, "--input", tif_path, "--out_dir", out_dir]
        if thr is not None:
            cmd += ["--threshold", str(thr)]

        try:
            QgsMessageLog.logMessage("Running: " + " ".join(cmd), PLUGIN_NAME, level=Qgis.Info)
            p = subprocess.run(cmd, capture_output=True, text=True)
            if p.returncode != 0:
                QMessageBox.critical(self.iface.mainWindow(), PLUGIN_NAME, self.tr("Engine error:\n") + p.stderr)
                return

            QMessageBox.information(self.iface.mainWindow(), PLUGIN_NAME, self.tr("Done!\n\n") + p.stdout)

            shp = None
            for line in p.stdout.splitlines():
                if line.startswith("shp="):
                    shp = line.split("=",1)[1].strip()
            if shp and os.path.exists(shp):
                self.iface.addVectorLayer(shp, os.path.basename(shp), "ogr")

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), PLUGIN_NAME, str(e))
