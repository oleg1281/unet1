
def classFactory(iface):
    from .stone_detector import StoneDetectorPlugin
    return StoneDetectorPlugin(iface)
